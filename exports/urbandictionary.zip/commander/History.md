
0.3.0 / 2011-10-31 
==================

  * Added support for long flags only. Closes #18

0.2.1 / 2011-10-24 
==================

  * "node": ">= 0.4.x < 0.7.0". Closes #20

0.2.0 / 2011-09-26 
==================

  * Allow for defaults that are not just boolean. Default peassignment only occurs for --no-*, optional, and required arguments. [Jim Isaacs]

0.1.0 / 2011-08-24 
==================

  * Added support for custom `--help` output

0.0.5 / 2011-08-18 
==================

  * Changed: when the user enters nothing prompt for password again
  * Fixed issue with passwords beginning with numbers [NuckChorris]

0.0.4 / 2011-08-15 
==================

  * Fixed `Commander#args`

0.0.3 / 2011-08-15 
==================

  * Added default option value support

0.0.2 / 2011-08-15 
==================

  * Added mask support to `Command#password(str[, mask], fn)`
  * Added `Command#password(str, fn)`

0.0.1 / 2010-01-03
==================

  * Initial release
